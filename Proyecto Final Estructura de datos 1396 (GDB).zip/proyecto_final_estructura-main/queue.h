#ifndef QUEUE_H
#define QUEUE_H

void info_queue();

#endif
