#ifndef STACK_H
#define STACK_H

void info_stack();


#endif
