#ifndef GRAPHS_H
#define GRAPHS_H

void info_graphs();

#endif
