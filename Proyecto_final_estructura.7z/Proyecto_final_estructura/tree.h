#include <stdio.h>

void info_trees(){
    printf("Los Arboles son las estructuras de datos mas utilizadas, pero tambien una de las mas complejas, Los Arboles se caracterizan por almacenar sus nodos en forma jerarquica y no en forma lineal como las listas ligadas, colas, pilas, etc., \n");
    printf("\nDatos importantes de los Arboles\n\nPara comprender mejor que es un arbol comenzaremos explicando como esta estructurado.\n\n-Nodos: Se le llama Nodo a cada elemento que contiene un Arbol.\n\n-Nodo Raiz: Se refiere al primer nodo de un Arbol, Solo un nodo del Arbol puede ser la Raiz.\n\n-Nodo Padre: Se utiliza este termino para llamar a todos aquellos nodos que tiene al menos un hijo.\n\n-Nodo Hijo: Los hijos son todos aquellos nodos que tiene un padre.\n\n-Nodo Hermano: Los nodos hermanos son aquellos nodos que comparte a un mismo padre en comun dentro de la estructura.\n\n-Nodo Hoja: Son todos aquellos nodos que no tienen hijos, los cuales siempre se encuentran en los extremos de la estructura.\n\n-Nodo Rama: Estos son todos aquellos nodos que no son la raiz y que ademas tiene al menos un hijo.\n");
    printf("\nLos arboles ademas de los nodos tiene otras propiedades importantes que son utilizadas en diferentes ambitos los cuales son:\n\nNivel: Nos referimos como nivel a cada generacion dentro del arbol. Por ejemplo, cuando a un nodo hoja le agregamos un hijo, el nodo hoja pasa a ser un nodo rama, pero ademas el arbol crece una generacion por lo que el Arbol tiene un nivel mas. Cada generacion tiene un numero de Nivel distinto que las demas generaciones.\n");
    printf("\nAltura: Le llamamos Altura al numero maximo de niveles de un Arbol.\n");
    printf("\nPeso: Conocemos como peso a el numero de nodos que tiene un Arbol. Este factor es importante porque nos da una idea del tamaño del arbol y el tamaño en memoria que nos puede ocupar en tiempo de ejecucion (Complejidad Espacial en analisis de algoritmos.)\n");
    printf("\nOrden: El Orden de un arbol es el numero maximo de hijos que puede tener un Nodo.\n");
    printf("\nGrado: El grado se refiere al numero mayor de hijos que tiene alguno de los nodos del Arbol y esta limitado por el Orden, ya que este indica el numero maximo de hijos que puede tener un nodo.\n");

}  
