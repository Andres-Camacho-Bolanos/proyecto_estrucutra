# proyecto_estrucutra
Repositorio que contiene los archivos necesarios para realizar un programa en C, que sea capaz de funcionar como agenda personal.
