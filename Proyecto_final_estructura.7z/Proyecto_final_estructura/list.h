#include <stdio.h>


void info_list(){

    printf("En programacion, una lista es un tipo de estructura de datos que permite almacenar y acceder a un conjunto de elementos en un orden especifico. Las listas son similares a los arreglos, pero a diferencia de los arreglos, las listas en algunos lenguajes de programacion permiten insertar y eliminar elementos en cualquier posicion en tiempo de ejecucion.\n");
    printf("\nLas listas son una estructura de datos dinamica lo que significa que su tamaño puede cambiar dinamicamente dependiendo de la cantidad de elementos que se agreguen o quiten.\n");
    printf("\nAlgunas operaciones comunes que se pueden realizar con listas incluyen:\n\n-Agregar un elemento a la lista (append)\n\n-Insertar un elemento en una posicion especifica (insert)\n\n-Remover un elemento especifico (remove)\n\n-Acceder a un elemento en una posicion especifica (index)\n\n-Encontrar el numero de elementos en la lista (length/size)");
    printf("\n\nLa sintaxis para crear una lista y utilizar algunas de estas operaciones varia entre los diferentes lenguajes de programacion, pero en general las listas son una herramienta muy util en la mayoria de los lenguajes para trabajar con colecciones de datos ordenadas.\n");
}
